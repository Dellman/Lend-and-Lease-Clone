// config/database.js
module.exports = {
    'connection': {
        'host': '198.211.126.133',
        'user': 'admin',
        'password': 'password'
    },
	'database': 'lendandloan',
    'users_table': 'users'
};
